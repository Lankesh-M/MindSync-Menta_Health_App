class Patient {
  final String name;
  final int age;
  final String password;

  Patient({required this.name, required this.age, required this.password});
}
