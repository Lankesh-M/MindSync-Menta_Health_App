class Question {
  String text;
  double score;
  String selectedOption = '';

  Question(this.text, this.score);
}
